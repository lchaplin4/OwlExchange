# =====================================
# OwlExchange - Item Posting with SQLite
# =====================================

import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename

# -------------------------
# Flask App Setup
# -------------------------
app = Flask(__name__)
app.secret_key = "supersecretkey"

# Configure upload folder for images
UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# -------------------------
# Database Helper Functions
# -------------------------

# Initialize the database and create table if not exists
def init_db():
    conn = sqlite3.connect("owl_exchange.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_first TEXT NOT NULL,
            seller_last TEXT NOT NULL,
            product_name TEXT NOT NULL,
            product_details TEXT NOT NULL,
            condition TEXT NOT NULL,
            price REAL NOT NULL,
            disposition TEXT NOT NULL,
            image TEXT
        )
    """)
    conn.commit()
    conn.close()

# Insert new item into database
def insert_item(seller_first, seller_last, product_name, product_details,
                condition, price, disposition, image):
    conn = sqlite3.connect("owl_exchange.db")
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO items 
        (seller_first, seller_last, product_name, product_details, condition, price, disposition, image)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (seller_first, seller_last, product_name, product_details, condition, price, disposition, image))
    conn.commit()
    conn.close()

# Fetch all items from database
def fetch_items():
    conn = sqlite3.connect("owl_exchange.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM items")
    items = cursor.fetchall()
    conn.close()
    return items

# -------------------------
# Routes
# -------------------------

@app.route("/")
def home():
    items = fetch_items()
    return render_template("home.html", items=items)

@app.route("/post_item", methods=["GET", "POST"])
def post_item():
    if request.method == "POST":
        # Collect form data
        seller_first = request.form.get("seller_first")
        seller_last = request.form.get("seller_last")
        product_name = request.form.get("product_name")
        product_details = request.form.get("product_details")
        condition = request.form.get("condition")
        price = request.form.get("price")
        disposition = request.form.get("disposition")

        # Handle image upload
        image = request.files["image"]
        image_filename = None
        if image and image.filename != "":
            filename = secure_filename(image.filename)
            image_filename = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            image.save(image_filename)

        # Insert into database
        insert_item(seller_first, seller_last, product_name, product_details,
                    condition, price, disposition, image_filename)

        flash("Item posted successfully!")
        return redirect(url_for("home"))

    return render_template("post_item.html")

# -------------------------
# Run the App
# -------------------------
if __name__ == "__main__":
    init_db()  # Make sure DB is initialized
    app.run(debug=True)
